"""
Routage racine.

L'API vit sous /api/. L'administration Django sous /admin/ sert d'outil
d'édition à l'équipe scientifique, en complément de l'administration
intégrée au front-end.

En production (cPanel, app Python unique), Django sert aussi le front
compilé : tout ce qui ne commence pas par admin/, api/, static/ ou media/
renvoie dist/index.html et laisse le routeur React (BrowserRouter) prendre
la main — le même rôle que le .htaccess de rewrite sur un hébergement
purement statique.
"""

from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.http import HttpResponse, JsonResponse
from django.urls import include, path, re_path

admin.site.site_header = "KINEDOK ACADÉMIE"
admin.site.site_title = "KINEDOK ACADÉMIE"
admin.site.index_title = "Administration"


def health(_request):
    return JsonResponse({"status": "ok"})


urlpatterns = [
    path("admin/", admin.site.urls),
    path("api/health/", health, name="health"),
    path("api/auth/", include("accounts.urls")),
    path("api/content/", include("content.urls")),
    path("api/promotions/", include("promotions.urls")),
]

urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

if not settings.DEBUG and settings.FRONTEND_DIST_DIR.is_dir():
    _index_path = settings.FRONTEND_DIST_DIR / "index.html"
    _index_html = _index_path.read_text(encoding="utf-8")

    def serve_frontend(_request, **_kwargs):
        return HttpResponse(_index_html, content_type="text/html; charset=utf-8")

    urlpatterns += [
        re_path(r"^(?!api/|admin/|static/|media/).*$", serve_frontend, name="frontend"),
    ]
